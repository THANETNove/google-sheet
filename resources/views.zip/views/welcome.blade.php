@extends('layouts.app')

@section('content')
    @include('auth.login')
@endsection
