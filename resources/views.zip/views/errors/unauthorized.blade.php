<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unauthorized</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            text-align: center;
            padding: 50px;
        }

        h1 {
            color: #dc3545;
        }

        p {
            color: #6c757d;
        }

        a {
            text-decoration: none;
            color: #007bff;
        }
    </style>
</head>

<body>
    <h1>401 Unauthorized</h1>
    <p>คุณไม่มีสิทธิ์เข้าถึงหน้านี้</p>
    {{--  <p><a href="/">กลับสู่หน้าหลัก</a></p> --}}
</body>

</html>
